//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Mine.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_MINETYPE                    129
#define IDR_MENU                        130
#define IDB_MINE_COLOR                  133
#define IDB_MINE_GRAY                   134
#define IDB_NUM_COLOR                   135
#define IDB_NUM_GRAY                    136
#define IDB_BTN_COLOR                   137
#define IDB_BTN_GRAY                    138
#define IDD_DLG_CUSTOM                  140
#define IDD_RANK                        141
#define IDR_WAVE_CLOCK                  142
#define IDR_WAVE_VICTORY                143
#define IDR_WAVE_DEAD                   144
#define IDD_NEWREC                      145
#define IDC_EDIT1                       1005
#define IDC_EDIT2                       1006
#define IDC_EDIT3                       1007
#define IDC_OK                          1008
#define IDC_CANNCEL                     1009
#define IDC_PRI_CAMP                    1009
#define IDC_PRI_HOLDER                  1010
#define IDC_PRI_BEST                    1011
#define IDC_SEC_CAMP                    1012
#define IDC_SEC_HOLDER                  1013
#define IDC_SEC_BEST                    1014
#define IDC_ADV_CAMP                    1015
#define IDC_ADV_HOLDER                  1016
#define IDC_ADV_BEST                    1017
#define IDC_EDIT_CAMP                   1018
#define IDC_EDIT_HOLDER                 1019
#define IDC_LEVEL                       1020
#define IDM_START                       32771
#define IDM_HELP                        32772
#define IDM_ABOUT                       32773
#define IDM_LEVEL_PRIMARY               32774
#define IDM_LEVEL_SECONDARY             32775
#define IDM_LEVEL_ADVANCE               32776
#define IDM_LEVEL_CUSTOM                32777
#define IDM_MARK                        32778
#define IDM_COLOR                       32779
#define IDM_SOUND                       32780
#define IDM_RANK                        32781
#define IDM_EXIT                        32782

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        147
#define _APS_NEXT_COMMAND_VALUE         32783
#define _APS_NEXT_CONTROL_VALUE         1022
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
